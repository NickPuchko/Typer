from rest_framework import serializers
from .models import PhotoFont


class FontPhotoSerializer(serializers.ModelSerializer):
    class Meta:
        model = PhotoFont
        fields = ('file',)
