from django.conf.urls.static import static
from django.conf import settings
from django.urls import path
from .views import PhotoViewSet

urlpatterns = [
    path('upload/', PhotoViewSet.as_view(), name='upload'),
]
