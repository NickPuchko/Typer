from det_t import findC
from OPCV import opencv

name = 'img_new/img.png'
name = '../../media/upload_to/cf7caee433b08133cb0ab96fe7161b14.jpg'
name1 = 'resultat.png'

try:
    findC(name)
    opencv(name1)
except:
    print("Error")
    name1 = name
    opencv(name1)
